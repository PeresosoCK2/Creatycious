# creatycios - Scaffold (ready for GitHub)

Este repo contiene el scaffold inicial de Creatycios (frontend + backend) 
y archivos de despliegue para producción (docker-compose.prod.yml, nginx conf,
scripts de bootstrap y deploy, GitHub Actions workflow).

IMPORTANTE: Reemplaza variables sensibles en `.env.prod` y no subas secrets al repo.
