import React from 'react'
import { createRoot } from 'react-dom/client'
function App(){ return <div><h1>Creatycios Frontend</h1></div> }
createRoot(document.getElementById('root')!).render(<App />)
